package ru.job4j.io;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class CSVReader {
    public static void handle(ArgsName argsName) throws Exception {
        String delimiter = argsName.get("delimiter");
        File output = new File(argsName.get("out"));
        Path path = Paths.get(argsName.get("path"));
        List<List<String>> table = new ArrayList<>();
        try (Scanner sc = new Scanner(
                new BufferedReader(new FileReader(path.toFile())))) {
            while (sc.hasNextLine()) {
                String[] temp = sc.nextLine().split(delimiter);
                List<String> list = new ArrayList<>(Arrays.asList(temp));
                table.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try (PrintStream out = new PrintStream(new FileOutputStream(output.getAbsolutePath()))) {
            for (List<String> l : table) {
                for (String rsl : l) {
                    out.println(rsl);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
